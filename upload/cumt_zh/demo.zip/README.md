[![Build Status](https://travis-ci.com/XiangyunHuang/Thesis-Template-Bookdown.svg?branch=master)](https://travis-ci.com/XiangyunHuang/Thesis-Template-Bookdown)
---

## 中国矿业大学（北京）论文模板

> 最好的模板就是一篇基于模板的完整论文， 其所包含的公式、图片、表格等不再是 demo， 只有把真实场景中的使用形式呈现给使用者看， 才能真的让使用者少淌些坑。

---

感谢 [Pandoc](https://github.com/jgm/pandoc)、[TinyTeX](https://github.com/yihui/tinytex)、[bookdown](https://github.com/rstudio/bookdown) 的开发者们，特别是 [John MacFarlane](https://johnmacfarlane.net/) 和 [Yihui Xie](https://yihui.name/)

---

软件要求

- TinyTeX: latest
- Pandoc: 2.2.3.2 及以上
- rmarkdown: 1.10.12
- bookdown: 0.7.18

测试平台

- Ubuntu 14.04.5 (64位)
- Ubuntu 18.04.1 (64位)
- Windows 8.1 (64位)
- CentOS 7 (64位) 与 Pandoc 2.3
